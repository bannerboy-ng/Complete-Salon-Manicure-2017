var bannerboy = bannerboy || {};
bannerboy.main = function() {

	var width = 160;
	var height = 600;
	var banner = bannerboy.createElement({perspective: 1000, id: "banner", width: width, height: height, backgroundColor: "#ffffff", overflow: "hidden", cursor: "pointer", parent: document.body});

	// adform vars
	var clickTAGvalue = dhtml.getVar('clickTAG', 'http://www.example.com');
	var landingpagetarget = dhtml.getVar('landingPageTarget', '_blank');

	var images = [
		"frame_2.jpg", 
		"frame_1.jpg", 
		"product.png", 
		"cta_txt.png", 
		"cta_txt_hover.png", 
		"txt_1.png", 
		"logo.png", 
	];

	bannerboy.preloadImages(images, function() {

		/* Create elements
		================================================= */
		/* eslint-disable indent, no-unused-vars */
		
		var bottom_plate = bannerboy.createElement({backgroundColor: "#991733", top: 389, width: 160, height: 211, parent: banner});
		var top_plate = bannerboy.createElement({backgroundColor: "#ed0f69", width: 160, height: 389, parent: banner});
		var frame_container = bannerboy.createElement({top: 27, width: 160, height: 362, parent: banner});
			var frame_2 = bannerboy.createElement({backgroundImage: "frame_2.jpg", parent: frame_container});
			var frame_1 = bannerboy.createElement({backgroundImage: "frame_1.jpg", parent: frame_container});
		var product = bannerboy.createElement({backgroundImage: "product.png", left: 93, top: 444, parent: banner});
		var cta = bannerboy.createElement({left: 13, top: 550, width: 75, height: 22, parent: banner});
			var cta_base = bannerboy.createElement({backgroundColor: "#ed0f69", width: 75, height: 22, parent: cta});
			var cta_txt = bannerboy.createElement({backgroundImage: "cta_txt.png", left: 6, top: 7, parent: cta});
			var cta_hover = bannerboy.createElement({width: 75, height: 22, parent: cta});
				var cta_base_hover = bannerboy.createElement({backgroundColor: "#ffffff", width: 75, height: 22, parent: cta_hover});
				var cta_txt_hover = bannerboy.createElement({backgroundImage: "cta_txt_hover.png", left: 6, top: 7, parent: cta_hover});
		var txt_1 = bannerboy.createElement({backgroundImage: "txt_1.png", left: 13, top: 364, parent: banner});
		var logo_container = bannerboy.createElement({left: 39, top: 10, width: 121, height: 40, parent: banner});
			var logo = bannerboy.createElement({backgroundImage: "logo.png", parent: logo_container});

		var border = bannerboy.createElement({width: width, height: height, border: "1px solid #000", boxSizing: "border-box", parent: banner});
		
		/* eslint-enable indent, no-unused-vars */

		/* Adjustments
		================================================= */

		cta_hover.set({opacity: 0}); 
		frame_container.set({overflow:"hidden"});
		/* Initiate
		================================================= */

		/* Animations
		================================================= */

		frame_container.tl_in = new BBTimeline()
			.add("start")
			.chain()
			.to(frame_1, 0.01, {opacity: 0, ease: Linear.easeNone})
			.chain(0.5)
			.to(frame_1, 0.01, {opacity: 1, ease: Linear.easeNone})
			.chain(0.5)
			.add(function() {
				frame_container.tl_in.play("start");
			})

		/* Main Timeline
		================================================= */

		main_tl = new BBTimeline()
			.absolute(15)
			.add(function() {
				frame_container.tl_in.pause();
			})

		scrubber(main_tl);

		/* Interactions
		================================================= */
		banner.addEventListener("mouseenter", function() {
				cta_hover.to(0.0001, {opacity: 1})
		});

		banner.addEventListener("mouseleave", function() {
				cta_hover.to(0.0001, {opacity: 0})				
		});

		banner.onclick = function() {
		    window.open(clickTAGvalue, landingpagetarget); 
		}

	    /* Helper
		================================================= */

		/* Scrubber
		================================================= */
		function scrubber(tl) {
			if (window.location.origin == "file://") {
				bannerboy.include(["../bannerboy_scrubber.min.js"], function() {
					if (bannerboy.scrubberController) bannerboy.scrubberController.create({"main timeline": tl});
				});
			}
		}
	});
};